import socket
import sys
from time import sleep

HOST, PORT = "127.0.0.1", 9999
data = "Updates_from_AS_Number"
ASNumber= " 2222  "
Cost = "  Path_Cost = 3  "
Path = "Number_of_Nodes_in_thePath = 1"
 
 
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
	sock.connect((HOST, PORT))
	while 0<1:
	    sock.send(data + ':' + ASNumber + ':' + Cost + ':' + Path)
	    #sock.send(Cost)
	    #sock.send(Path)
	    received = sock.recv(1024)

	    sleep(10)


finally:
    sock.close ()
