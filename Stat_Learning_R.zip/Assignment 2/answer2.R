library(e1071)

weather_kc=read.csv("kc_weather_srt.csv",header = T)
temp.F=weather_kc$Temp.F
humidity.perc=weather_kc$Humidity.percentage
precip.in=weather_kc$Precip.in

attach(weather_kc)

#temp1st=quantile(temp.F,.2)
#temp2nd=quantile(temp.F,.4)
#temp3rd=quantile(temp.F,.6)
#temp4th=quantile(temp.F,.8)
#temp5th=quantile(temp.F,.5)
#temp6th=quantile(temp.F,.6)
#temp7th=quantile(temp.F,.7)
#temp8th=quantile(temp.F,.8)
#temp9th=quantile(temp.F,.9)

#humidity1st=quantile(humidity.perc,.2)
#humidity2nd=quantile(humidity.perc,.4)
#humidity3rd=quantile(humidity.perc,.6)
#humidity4th=quantile(humidity.perc,.8)
#humidity5th=quantile(humidity.perc,.5)
#humidity6th=quantile(humidity.perc,.6)
#humidity7th=quantile(humidity.perc,.7)
#humidity8th=quantile(humidity.perc,.8)
#humidity9th=quantile(humidity.perc,.9)

#precip1st=quantile(precip.in,.4)
#precip2nd=quantile(precip.in,.8)


weather_kc$precip_Qaul <- with(weather_kc, precip.in)
weather_kc[,10] <- ifelse(weather_kc[,10]<.09,"Precip1st",ifelse(weather_kc[,10]<1.2,"Precip2nd","PrecipLast"))
weather_kc$precip_Qaul = as.factor(weather_kc$precip_Qaul)

weather_kc$humidity_Qaul <- with(weather_kc, humidity.perc)
weather_kc[,11] <- ifelse(weather_kc[,11]<35,"Humidity1st",
                          ifelse(weather_kc[,11]<70,"Humidity2nd",
                                 ifelse(weather_kc[,11]<91,"Humidity3rd","HumidityLast")))



weather_kc$humidity_Qaul = as.factor(weather_kc$humidity_Qaul)

weather_kc$temp_Qaul <- with(weather_kc, temp.F)
weather_kc[,12] <- ifelse(weather_kc[,12]<26,"Temp1st",
                          ifelse(weather_kc[,12]<44,"Temp2nd",
                                 ifelse(weather_kc[,12]<87,"Temp3rd","TempLast")))


weather_kc$temp_Qaul = as.factor(weather_kc$temp_Qaul)
attach(weather_kc)



n=366
nt=290
neval=n-nt
rep=100
errlin=dim(rep)
Accuracy=dim(rep)
Precision_r=dim(rep)
Precision_s=dim(rep)
Precision_th=dim(rep)
Recall_r=dim(rep)
Recall_s=dim(rep)
Recall_th=dim(rep)

for (k in 1:rep) {
  training=sample(1:n,nt)
  weather_kc_train=weather_kc[training,]
  weather_kc_test= weather_kc[-training,]
  
  weatherB_model=naiveBayes(Events ~ temp_Qaul+humidity_Qaul+precip_Qaul,data=weather_kc_train)
  weather_pred <- predict(weatherB_model, weather_kc_test,type="class")
  tablin=table(weather_kc_test$Events, weather_pred)
  
  
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1]+tablin[3,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2]+tablin[3,2])
  Precision_th[k] = tablin[3,3]/(tablin[1,3]+tablin[2,3]+tablin[3,3])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2]+tablin[1,3])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2]+tablin[2,3])
  Recall_th[k] = tablin[3,3]/(tablin[3,1]+tablin[3,2]+tablin[3,3])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

merrlin=mean(errlin)
merrlin
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Precision_th)
mean(Recall_r)
mean(Recall_s)
mean(Recall_th)


#################################

## Temp.F 
weather_kc2=read.csv("kc_weather_srt.csv",header = T)
n=366
nt=290
neval=n-nt
rep=100
errlin=dim(rep)
Accuracy=dim(rep)
Precision_r=dim(rep)
Precision_s=dim(rep)
Precision_th=dim(rep)
Recall_r=dim(rep)
Recall_s=dim(rep)
Recall_th=dim(rep)

for (k in 1:rep) {
  training=sample(1:n,nt)
  weather_kc_train=weather_kc2[training,]
  weather_kc_test= weather_kc2[-training,]
  
  weatherB_model2=naiveBayes(Events ~ Temp.F,data=weather_kc_train)
  weather_pred <- predict(weatherB_model, weather_kc_test,type="class")
  tablin=table(weather_kc_test$Events, weather_pred)
  
  
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1]+tablin[3,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2]+tablin[3,2])
  Precision_th[k] = tablin[3,3]/(tablin[1,3]+tablin[2,3]+tablin[3,3])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2]+tablin[1,3])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2]+tablin[2,3])
  Recall_th[k] = tablin[3,3]/(tablin[3,1]+tablin[3,2]+tablin[3,3])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

merrlin=mean(errlin)
merrlin
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Precision_th)
mean(Recall_r)
mean(Recall_s)
mean(Recall_th)


##########################
## Considering all predictors

for (k in 1:rep) {
  training=sample(1:n,nt)
  weather_kc_train=weather_kc2[training,]
  weather_kc_test= weather_kc2[-training,]
  
  weatherB_model=naiveBayes(Events ~.,data=weather_kc_train)
  weather_pred <- predict(weatherB_model, weather_kc_test,type="class")
  tablin=table(weather_kc_test$Events, weather_pred)
  
  
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1]+tablin[3,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2]+tablin[3,2])
  Precision_th[k] = tablin[3,3]/(tablin[1,3]+tablin[2,3]+tablin[3,3])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2]+tablin[1,3])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2]+tablin[2,3])
  Recall_th[k] = tablin[3,3]/(tablin[3,1]+tablin[3,2]+tablin[3,3])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Precision_th)
mean(Recall_r)
mean(Recall_s)
mean(Recall_th)
