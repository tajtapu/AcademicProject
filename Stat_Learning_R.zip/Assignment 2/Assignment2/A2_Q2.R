weather_kc=read.csv("C:/Users/taj_t/Desktop/Assignment2/kc_weather_srt.csv",header = T)

weather_kc$precip_Qaul <- with(weather_kc, weather_kc$Precip.in)
weather_kc[,10] <- ifelse(weather_kc[,10]<.1,"Precip1st",ifelse(weather_kc[,10]<1.2,"Precip2nd","PrecipLast"))
weather_kc$precip_Qaul = as.factor(weather_kc$precip_Qaul)


weather_kc$humidity_Qaul <- with(weather_kc, weather_kc$Humidity.percentage)
weather_kc[,11] <- ifelse(weather_kc[,11]<40,"Humidity1st",
                          ifelse(weather_kc[,11]<70,"Humidity2nd",
                                 ifelse(weather_kc[,11]<90,"Humidity3rd","HumidityLast")))
weather_kc$humidity_Qaul = as.factor(weather_kc$humidity_Qaul)


weather_kc$temp_Qaul <- with(weather_kc, weather_kc$Temp.F)
weather_kc[,12] <- ifelse(weather_kc[,12]<25,"Temp1st",
                          ifelse(weather_kc[,12]<50,"Temp2nd",
                                 ifelse(weather_kc[,12]<90,"Temp3rd","TempLast")))
weather_kc$temp_Qaul = as.factor(weather_kc$temp_Qaul)

n=366
nt=290
neval=n-nt
rep=100
errlin=dim(rep)
Accuracy=dim(rep)
Precision=dim(rep)
Recall=dim(rep)

for (k in 1:rep) {
  training=sample(1:n,nt)
  weather_kc_train=weather_kc[training,]
  weather_kc_test= weather_kc[-training,]
  
  weatherB_model=naiveBayes(Events ~ temp_Qaul+humidity_Qaul+precip_Qaul,data=weather_kc_train)
  weather_pred = predict(weatherB_model, weather_kc_test,type="class")
  tablin=table(weather_kc_test$Events, weather_pred)
 
  errlin[k] = (neval-sum(diag(tablin)))/neval
  Accuracy[k] = sum(diag(tablin))/neval
  Precision[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1])
  Recall[k] = tablin[1,1]/sum(tablin[1,])
}

mean(errlin)
mean(Accuracy)
mean(Precision)
mean(Recall)

#Temp.F 
weather_kc_T=read.csv("C:/Users/taj_t/Desktop/Assignment2/kc_weather_srt.csv",header = T)
n=366
nt=290
neval=n-nt
rep=100
errlin=dim(rep)
Accuracy=dim(rep)
Precision=dim(rep)
Recall=dim(rep)

for (k in 1:rep) {
  training=sample(1:n,nt)
  weather_kc_train=weather_kc_T[training,]
  weather_kc_test= weather_kc_T[-training,]
  
  weatherB_model_T=naiveBayes(Events ~ Temp.F,data=weather_kc_train)
  weather_pred = predict(weatherB_model_T, weather_kc_test,type="class")
  tablin=table(weather_kc_test$Events, weather_pred)
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
  Accuracy[k] = sum(diag(tablin))/neval
  Precision[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1])
  Recall[k] = tablin[1,1]/sum(tablin[1,])
}
mean(errlin)
mean(Accuracy)
mean(Precision)
mean(Recall)

#Considering all

weather_kc_A=read.csv("C:/Users/taj_t/Desktop/Assignment2/kc_weather_srt.csv",header = T)
n=366
nt=290
neval=n-nt
rep=100
errlin=dim(rep)
Accuracy=dim(rep)
Precision=dim(rep)
Recall=dim(rep)

for (k in 1:rep) {
  training=sample(1:n,nt)
  weather_kc_train=weather_kc_A[training,]
  weather_kc_test= weather_kc_A[-training,]
  
  weatherB_model_A=naiveBayes(Events ~.,data=weather_kc_train)
  weather_pred = predict(weatherB_model_A, weather_kc_test,type="class")
  tablin=table(weather_kc_test$Events, weather_pred)
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
  Accuracy[k] = sum(diag(tablin))/neval
  Precision[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1])
  Recall[k] = tablin[1,1]/sum(tablin[1,])
}
mean(errlin)
mean(Accuracy)
mean(Precision)
mean(Recall)