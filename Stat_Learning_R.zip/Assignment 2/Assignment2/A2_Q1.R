weather= read.csv("C:/Users/taj_t/Desktop/Assignment2/kc_weather_srt.csv", header = T)
dataset1 =weather$Events == "Rain_Thunderstorm"
new_weather=weather[!dataset1,]
summary(new_weather)
attach(new_weather)
write.csv(new_weather,file='kc_weather_srt2.csv')
new_weather_wrt=read.csv("kc_weather_srt2.csv", header = T)
summary(new_weather_wrt)
fit1 = glm(Events~.-Date,data=new_weather_wrt,family=binomial)
summary(fit1)
fit2 = glm(Events~Dew_Point.F+Precip.in,data=new_weather_wrt,family=binomial)
summary(fit2)
fit3 = glm(Events~Dew_Point.F,data=new_weather_wrt,family=binomial)
summary(fit3)

n=226
nt=180
neval=n-nt
rep=100
errlin=dim(rep)
Accuracy=dim(rep)
Precision=dim(rep)
Recall=dim(rep)

#Logistic

for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.logit=glm(Events~Dew_Point.F,data=new_weather_wrt[train,],family=binomial)
  weather.prob=predict(weather.logit,new_weather_wrt[-train,],type="response")
  weather.pred= rep("Snow",dim(new_weather_wrt[-train,])[1])
  weather.pred[weather.prob < .5] ="Rain"
  tablin=table(weather.pred, new_weather_wrt[-train,]$Events)
  
  
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision[k] = tablin[1,1]/(tablin[1,1]+tablin[1,])
  
  
  Recall[k] = tablin[1,1]/sum(tablin[1,])

  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}
mean_errlin=mean(errlin)
mean_errlin
#LDA
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.lda_train = lda(Events~.-(Date+Visibility.mi+Precip.in),new_weather_wrt[train,])
  predict(weather.lda_train,new_weather_wrt[-train,])$class
  tablin=table(new_weather_wrt$Events[-train],predict(weather.lda_train,new_weather_wrt[-train,])$class)
  
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision[k] = tablin[1,1]/(tablin[1,1]+tablin[1,])
  
  
  Recall[k] = tablin[1,1]/sum(tablin[1,])
  
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

#QDA
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.qda_train = qda(Events~.-(Date+Visibility.mi+Precip.in),new_weather_wrt[train,])
  predict(weather.qda_train,new_weather_wrt[-train,])$class
  tablin=table(new_weather_wrt$Events[-train],predict(weather.qda_train,new_weather_wrt[-train,])$class)
  
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1])
  
  
  Recall[k] = tablin[1,1]/sum(tablin[1,])
  
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

#KNN
for (k in 1:rep) {
  train = sample(1:n,nt)
  weather.knn.Train = new_weather_wrt[train,2:8]
  weather.knn.Test = new_weather_wrt[-train,2:8]
  weather.trainLabels <- new_weather_wrt[train,9]
  weather.knn3 = knn(weather.knn.Train,weather.knn.Test,weather.trainLabels,k=46)
  
  tablin=table(weather.knn3,new_weather_wrt[-train,9])
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision[k] = tablin[1,1]/(tablin[1,1]+tablin[1,])
  
  
  Recall[k] = tablin[1,1]/sum(tablin[1,])
  
}  

#II)

hist(new_weather_wrt$Wi)
#LDA
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.lda_train = lda(Events~.-(Date+Precip.in+Visibility.mi+Sea_Level_Press.in),new_weather_wrt[train,])
  predict(weather.lda_train,new_weather_wrt[-train,])$class
  tablin=table(new_weather_wrt$Events[-train],predict(weather.lda_train,new_weather_wrt[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision[k] = tablin[1,1]/(tablin[1,1]+tablin[1,])
  
  
  Recall[k] = tablin[1,1]/sum(tablin[1,])
  
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
  
}
#QDA
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.qda_train = qda(Events~.-(Date+Precip.in+Visibility.mi+Sea_Level_Press.in),new_weather_wrt[train,])
  predict(weather.qda_train,new_weather_wrt[-train,])$class
  tablin=table(new_weather_wrt$Events[-train],predict(weather.qda_train,new_weather_wrt[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision[k] = tablin[1,1]/(tablin[1,1]+tablin[1,])
  
  
  Recall[k] = tablin[1,1]/sum(tablin[1,])
  
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}
#b)
hist(weather$Precip.in)
n=366
nt=290
neval=n-nt
rep=100
errlin=dim(rep)
Accuracy=dim(rep)
Precision=dim(rep)
Recall=dim(rep)
#LDA
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.lda_train = lda(Events~Humidity.percentage+Sea_Level_Press.in+Wind.mph+Dew_Point.F+Temp.F,weather[train,])
  predict(weather.lda_train,weather[-train,])$class
  tablin=table(weather$Events[-train],predict(weather.lda_train,weather[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision[k] = tablin[1,1]/(tablin[1,1]+tablin[1,])
  
  
  Recall[k] = tablin[1,1]/sum(tablin[1,])
  
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}
#QDA
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.qda_train = qda(Events~Humidity.percentage+Sea_Level_Press.in+Wind.mph+Temp.F+Dew_Point.F,weather[train,])
  predict(weather.qda_train,weather[-train,])$class
  tablin=table(weather$Events[-train],predict(weather.qda_train,weather[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision[k] = tablin[1,1]/(tablin[1,1]+tablin[1,])
  
  
  Recall[k] = tablin[1,1]/sum(tablin[1,])
  
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}