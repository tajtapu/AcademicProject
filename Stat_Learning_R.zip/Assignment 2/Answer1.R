
weather <- read.csv("kc_weather_srt.csv", header = T)
attach(weather)
#a) subsetting the data by taking rain and snow
cond1 <- weather$Events == "Rain_Thunderstorm"
new_weather <- weather[!cond1,]
summary(new_weather)
attach(new_weather)
write.csv(new_weather, file='kc_weather_srt2.csv')
new_weather1 <- read.csv("kc_weather_srt2.csv", header = T)
summary(new_weather1)
new_weather1$X <- NULL
# a) i)
#logistis reg
fit1 = glm(Events~.-Date,data=new_weather1,family=binomial)
summary(fit1)
#from the p-values we can conclude
fit2 = glm(Events~Dew_Point.F+Precip.in,data=new_weather1,family=binomial)
summary(fit2)
fit3 = glm(Events~Dew_Point.F,data=new_weather1,family=binomial)
summary(fit3)

n=226
nt=180
neval=n-nt
rep=100
errlin=dim(rep)
Accuracy=dim(rep)
Precision_r=dim(rep)
Precision_s=dim(rep)
Recall_r=dim(rep)
Recall_s=dim(rep)
# for 100 replications, look it through k

for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.logit=glm(Events~Dew_Point.F,data=new_weather1[train,],family=binomial)
  weather.prob=predict(weather.logit,new_weather1[-train,],type="response")
  weather.pred= rep("Snow",dim(new_weather1[-train,])[1])
  weather.pred[weather.prob < .5] ="Rain"
  tablin=table(weather.pred, new_weather1[-train,]$Events)
  
  
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

merrlin=mean(errlin)
merrlin
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Recall_r)
mean(Recall_s)




#lda
library(MASS)
library(car)

library(class)
n=226
nt=180
neval=n-nt
rep=100
errlin=dim(rep)
Accuracy=dim(rep)
Precision_r=dim(rep)
Precision_s=dim(rep)
Recall_r=dim(rep)
Recall_s=dim(rep)
# for 100 replications, look it through k

for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.lda_train = lda(Events~.-(Date+Visibility.mi+Precip.in),new_weather1[train,])
  predict(weather.lda_train,new_weather1[-train,])$class
  tablin=table(new_weather1$Events[-train],predict(weather.lda_train,new_weather1[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

merrlin=mean(errlin)
merrlin
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Recall_r)
mean(Recall_s)

#qda
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.qda_train = qda(Events~.-(Date+Visibility.mi+Precip.in),new_weather1[train,])
  predict(weather.qda_train,new_weather1[-train,])$class
  tablin=table(new_weather1$Events[-train],predict(weather.qda_train,new_weather1[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

merrlin=mean(errlin)
merrlin
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Recall_r)
mean(Recall_s)

#KNN

for (k in 1:rep) {
  train = sample(1:n,nt)
  weather.knn.Train = new_weather1[train,2:8]
  weather.knn.Test = new_weather1[-train,2:8]
  weather.trainLabels <- new_weather1[train,9]
  weather.knn3 = knn(weather.knn.Train,weather.knn.Test,weather.trainLabels,k=46)
  
  tablin=table(weather.knn3,new_weather1[-train,9])
  Accuracy[k] =sum(diag(tablin))/neval
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2])
  
}
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Recall_r)
mean(Recall_s)

#ii)
#lda


hist(new_weather1$Wi) # put all the predictor variables and see whether they are normal #precip, visibility,sea level are not normal 

for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.lda_train = lda(Events~.-(Date+Precip.in+Visibility.mi+Sea_Level_Press.in),new_weather1[train,])
  predict(weather.lda_train,new_weather1[-train,])$class
  tablin=table(new_weather1$Events[-train],predict(weather.lda_train,new_weather1[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval

  }

merrlin=mean(errlin) 
merrlin
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Recall_r)
mean(Recall_s)

#qda
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.qda_train = qda(Events~.-(Date+Precip.in+Visibility.mi+Sea_Level_Press.in),new_weather1[train,])
  predict(weather.qda_train,new_weather1[-train,])$class
  tablin=table(new_weather1$Events[-train],predict(weather.qda_train,new_weather1[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

merrlin=mean(errlin)
merrlin
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Recall_r)
mean(Recall_s)

######################
######################

#b) 
# i)
#lda
library(MASS)
library(car)

library(class)
n=366
nt=290
neval=n-nt
rep=100
errlin=dim(rep)
Accuracy=dim(rep)
Precision_r=dim(rep)
Precision_s=dim(rep)
Precision_th=dim(rep)
Recall_r=dim(rep)
Recall_s=dim(rep)
Recall_th=dim(rep)
# for 100 replications, look it through k

for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.lda_train = lda(Events~.-Date,weather[train,])
  predict(weather.lda_train,weather[-train,])$class
  tablin=table(weather$Events[-train],predict(weather.lda_train,weather[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1]+tablin[3,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2]+tablin[3,2])
  Precision_th[k] = tablin[3,3]/(tablin[1,3]+tablin[2,3]+tablin[3,3])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2]+tablin[1,3])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2]+tablin[2,3])
  Recall_th[k] = tablin[3,3]/(tablin[3,1]+tablin[3,2]+tablin[3,3])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

merrlin=mean(errlin)
merrlin
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Precision_th)
mean(Recall_r)
mean(Recall_s)
mean(Recall_th)

#qda
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.qda_train = qda(Events~.-Date,weather[train,])
  predict(weather.qda_train,weather[-train,])$class
  tablin=table(weather$Events[-train],predict(weather.qda_train,weather[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1]+tablin[3,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2]+tablin[3,2])
  Precision_th[k] = tablin[3,3]/(tablin[1,3]+tablin[2,3]+tablin[3,3])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2]+tablin[1,3])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2]+tablin[2,3])
  Recall_th[k] = tablin[3,3]/(tablin[3,1]+tablin[3,2]+tablin[3,3])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

merrlin=mean(errlin)
merrlin
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Precision_th)
mean(Recall_r)
mean(Recall_s)
mean(Recall_th)

#KNN

for (k in 1:rep) {
  train = sample(1:n,nt)
  weather.knn.Train = weather[train,2:8]
  weather.knn.Test = weather[-train,2:8]
  weather.trainLabels <- weather[train,9]
  weather.knn3 = knn(weather.knn.Train,weather.knn.Test,weather.trainLabels,k=20)
  tablin=table(weather.knn3,weather[-train,9])
  Accuracy[k] =sum(diag(tablin))/neval
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1]+tablin[3,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2]+tablin[3,2])
  Precision_th[k] = tablin[3,3]/(tablin[1,3]+tablin[2,3]+tablin[3,3])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2]+tablin[1,3])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2]+tablin[2,3])
  Recall_th[k] = tablin[3,3]/(tablin[3,1]+tablin[3,2]+tablin[3,3])
  
  
}

tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Precision_th)
mean(Recall_r)
mean(Recall_s)
mean(Recall_th)

#ii)
#lda


hist(weather$Precip.in) # put all the predictor variables and see whether they are normal 
# temp, dew point,precip, visibility, are not normal 

#lda
library(MASS)
library(car)

library(class)
n=366
nt=290
neval=n-nt
rep=100
errlin=dim(rep)
Accuracy=dim(rep)
Precision_r=dim(rep)
Precision_s=dim(rep)
Precision_th=dim(rep)
Recall_r=dim(rep)
Recall_s=dim(rep)
Recall_th=dim(rep)
# for 100 replications, look it through k

for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.lda_train = lda(Events~Humidity.percentage+Sea_Level_Press.in+Wind.mph+Dew_Point.F+Temp.F,weather[train,])
  predict(weather.lda_train,weather[-train,])$class
  tablin=table(weather$Events[-train],predict(weather.lda_train,weather[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1]+tablin[3,1])
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2]+tablin[3,2])
  Precision_th[k] = tablin[3,3]/(tablin[1,3]+tablin[2,3]+tablin[3,3])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2]+tablin[1,3])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2]+tablin[2,3])
  Recall_th[k] = tablin[3,3]/(tablin[3,1]+tablin[3,2]+tablin[3,3])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

merrlin=mean(errlin)
merrlin
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Precision_th)
mean(Recall_r)
mean(Recall_s)
mean(Recall_th)

#qda
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather.qda_train = qda(Events~Humidity.percentage+Sea_Level_Press.in+Wind.mph+Temp.F+Dew_Point.F,weather[train,])
  predict(weather.qda_train,weather[-train,])$class
  tablin=table(weather$Events[-train],predict(weather.qda_train,weather[-train,])$class)
  Accuracy[k] = sum(diag(tablin))/neval
  
  Precision_r[k] = tablin[1,1]/(tablin[1,1]+tablin[2,1]+tablin[3,1])
  
  Precision_s[k] = tablin[2,2]/(tablin[1,2]+tablin[2,2]+tablin[3,2])
  Precision_th[k] = tablin[3,3]/(tablin[1,3]+tablin[2,3]+tablin[3,3])
  
  Recall_r[k] = tablin[1,1]/(tablin[1,1]+tablin[1,2]+tablin[1,3])
  Recall_s[k] = tablin[2,2]/(tablin[2,1]+tablin[2,2]+tablin[2,3])
  Recall_th[k] = tablin[3,3]/(tablin[3,1]+tablin[3,2]+tablin[3,3])
  
  errlin[k] = (neval-sum(diag(tablin)))/neval
}

merrlin=mean(errlin)
merrlin
tablin
mean(Accuracy)
mean(Precision_r)
mean(Precision_s)
mean(Precision_th)
mean(Recall_r)
mean(Recall_s)
mean(Recall_th)

