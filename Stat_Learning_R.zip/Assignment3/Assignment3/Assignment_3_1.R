rm(list=ls)
weather_kc= read.csv("C:/Users/taj_t/Desktop/Assignment3/kc_weather_srt.csv",header = TRUE)
weather_kc$Date = NULL

n=366
nt=290
neval=n-nt
rep=100
errlin_lin=dim(rep)
Accuracy_lin=dim(rep)
Precision_lin=dim(rep)
Recall_lin=dim(rep)

#SVM
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather_kc_train=weather_kc[train,]
  weather_kc_test= weather_kc[-train,]
  weather_kc_model_svm_lin= svm(Events ~ . , data = weather_kc_train, kernel = "linear")
  weather_kc_pred_svm_lin = predict(weather_kc_model_svm_lin,subset(weather_kc_test,select=-Events))
  tablin_svm_lin=table(weather_kc_test$Events,weather_kc_pred_svm_lin)
  
  Accuracy_lin[k] = sum(diag(tablin_svm_lin))/neval
  Precision_lin[k] = tablin_svm_lin[1,1]/(tablin_svm_lin[1,1]+tablin_svm_lin[2,1]+tablin_svm_lin[3,1])
  Recall_lin[k] = tablin_svm_lin[1,1]/(tablin_svm_lin[1,1]+tablin_svm_lin[1,2]+tablin_svm_lin[1,3])
  errlin_lin[k] = (neval-sum(diag(tablin_svm_lin)))/neval
}
confusionMatrix(weather_kc_pred_svm_lin,weather_kc_test$Events)

#LDA
n=366
nt=290
neval=n-nt
rep=100
errlin_lda=dim(rep)
Accuracy_lda=dim(rep)
Precision_lda=dim(rep)
Recall_lda=dim(rep)

for (k in 1:rep) {
  train=sample(1:n,nt)
  weather_kc_train=weather_kc[train,]
  weather_kc_test= weather_kc[-train,]
  weather_kc_lda= lda(Events~.,weather_kc_train)
  weather_kc_predict_lda = predict(weather_kc_lda,weather_kc_test)$class
  tablin_lda=table(weather_kc_test$Events,weather_kc_predict_lda)
  
  Accuracy_lda[k] = sum(diag(tablin_lda))/neval
  Precision_lda[k] = tablin_lda[1,1]/(tablin_lda[1,1]+tablin_lda[2,1]+tablin_lda[3,1])
  Recall_lda[k] = tablin_lda[1,1]/(tablin_lda[1,1]+tablin_lda[1,2]+tablin_lda[1,3])
  errlin_lda[k] = (neval-sum(diag(tablin_lda)))/neval
}
confusionMatrix(weather_kc_predict_lda,weather_kc_test$Events)

#QDA
n=366
nt=290
neval=n-nt
rep=100
errlin_qda=dim(rep)
Accuracy_qda=dim(rep)
Precision_qda=dim(rep)
Recall_qda=dim(rep)
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather_kc_train=weather_kc[train,]
  weather_kc_test= weather_kc[-train,]
  weather_kc_qda= qda(Events~.,weather_kc_train)
  weather_kc_predict_qda = predict(weather_kc_qda,weather_kc_test)$class
  tablin_qda=table(weather_kc_test$Events,weather_kc_predict_qda)
  
  Accuracy_qda[k] = sum(diag(tablin_qda))/neval
  Precision_qda[k] = tablin_qda[1,1]/(tablin_qda[1,1]+tablin_qda[2,1]+tablin_qda[3,1])
  Recall_qda[k] = tablin_qda[1,1]/(tablin_qda[1,1]+tablin_qda[1,2]+tablin_qda[1,3])
  errlin_qda[k] = (neval-sum(diag(tablin_qda)))/neval
}
confusionMatrix(weather_kc_predict_qda,weather_kc_test$Events)

#KNN
n=366
nt=290
neval=n-nt
rep=100
errlin_knn=dim(rep)
Accuracy_knn=dim(rep)
Precision_knn=dim(rep)
Recall_knn=dim(rep)
for (k in 1:rep) {
  train=sample(1:n,nt)
  weather_kc_train=weather_kc[train,]
  weather_kc_test= weather_kc[-train,]
  weather_kc_trainLabels = weather_kc_train$Events
  predict_knn = knn(weather_kc_train[1:7],weather_kc_test[1:7],weather_kc_trainLabels,k=13)
  tablin_knn=table(predict_knn,weather_kc_test$Events)
  
  Accuracy_knn[k] = sum(diag(tablin_knn))/neval
  Precision_knn[k] = tablin_knn[1,1]/(tablin_knn[1,1]+tablin_knn[2,1]+tablin_knn[3,1])
  Recall_knn[k] = tablin_knn[1,1]/(tablin_knn[1,1]+tablin_knn[1,2]+tablin_knn[1,3])
  errlin_knn[k] = (neval-sum(diag(tablin_knn)))/neval
}
confusionMatrix(predict_knn,weather_kc_test$Events)