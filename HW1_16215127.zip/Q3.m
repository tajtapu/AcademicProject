clear all;
im0 = imread('lena.png');  imshow(im0); title('lena');
im=rgb2gray(im0); imx = double(im(:));

f1 = [1 1 1; 1 0 0 ; 0 0 0]; f1=f1/3;
im1 = double(im) - double(imfilter(im, f1));
im1x = double(im1(:));

figure(); subplot(2,2,1); imagesc(im); title('lena');
subplot(2,2,2); imagesc(im1); colormap('gray'); title('prediction error');

[h, v]=hist(double(im1x(:)), 40);subplot(2,2,3); 
plot(v, h); grid on; hold on;title('error distribution');


for i=1:length(im1)
   for j=1:length(im1)
      l=im1(i,j);   
      g=golombnumber(l)
      golomb{i,j}=g;
     end
 end