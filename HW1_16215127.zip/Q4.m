clear all;
im0 = imread('lena.png');  imshow(im0); title('lena');
im=rgb2gray(im0); [h, w]=size(im); imx = double(im(:));
dct_q = load('dct_q.txt');

blk_size = 8; n_h_blk = fix(h/blk_size); n_w_blk = fix(w/blk_size); 
for j=1:n_h_blk
    for k=1:n_w_blk
        h_offs = (j-1)*blk_size; 
        w_offs = (k-1)*blk_size;
        im_blk{j, k} = im(h_offs+1:h_offs+blk_size, w_offs+1:w_offs+blk_size);         
        im_dct{j, k}  =  dct2(im_blk{j,k});        
    end
end

f1=fix(dct2(im(121:128,121:128))./dct_q)  
p1=im(121:128,121:128);
figure();subplot(1,2,1);imagesc(f1)
subplot(1,2,2);imagesc(p1)

f2=fix(dct2(im(161:168,161:168))./dct_q)  
p2=im(161:168,161:168);
figure();subplot(1,2,1);imagesc(f2)
subplot(1,2,2);imagesc(p2)

f3=fix(dct2(im(176:183,120:127))./dct_q)  
p3=im(176:183,120:127);
figure();subplot(1,2,1);imagesc(f3)
subplot(1,2,2);imagesc(p3)

f4=fix(dct2(im(145:152,180:187))./dct_q)  
p4=im(145:152,180:187);
figure();subplot(1,2,1);imagesc(f4)
subplot(1,2,2);imagesc(p4)